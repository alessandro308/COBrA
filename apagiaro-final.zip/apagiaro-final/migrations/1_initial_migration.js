var Migrations = artifacts.require("./Migrations.sol");
var Catalog = artifacts.require("./catalog.sol");

module.exports = function(deployer) {
  deployer.deploy(Migrations);
  deployer.deploy(Catalog);
};
